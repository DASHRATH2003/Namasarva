import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

class BookingsScreen extends StatefulWidget {
  @override
  State<BookingsScreen> createState() => _BookingsScreenState();
}

class _BookingsScreenState extends State<BookingsScreen> {
  @override
  Widget build(BuildContext context) {
    final currentUser = FirebaseAuth.instance.currentUser;

    if (currentUser == null) {
      return Center(
        child: Text('Please login to view your bookings'),
      );
    }

    return Scaffold(
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('customers')
            .doc(currentUser.uid)
            .collection('bookings')
            .orderBy('createdAt', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error loading bookings'));
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.receipt_long, size: 60, color: Colors.grey),
                  SizedBox(height: 16),
                  Text(
                    'No bookings yet',
                    style: TextStyle(fontSize: 18, color: Colors.grey),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Your upcoming trips will appear here',
                    style: TextStyle(color: Colors.grey),
                  ),
                ],
              ),
            );
          }

          return ListView(
            padding: EdgeInsets.all(16),
            children: snapshot.data!.docs.map((booking) {
              final journey = booking['journeyDetails'] as Map<String, dynamic>;
              final passengers = List<Map<String, dynamic>>.from(booking['passengerDetails']);
              final date = (booking['createdAt'] as Timestamp).toDate();
              final formattedDate = DateFormat('MMM dd, yyyy').format(date);
              final formattedTime = DateFormat('hh:mm a').format(date);

              return Container(
                margin: EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 6,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Header with status
                    Container(
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: _getStatusColor(booking['bookingStatus']),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(12),
                          topRight: Radius.circular(12),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            booking['ticketNumber'],
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            booking['bookingStatus'].toString().toUpperCase(),
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),

                    // Journey details
                    Padding(
                      padding: EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Route
                          Container(
                            width: double.infinity,
                            child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Container(
                                    padding: EdgeInsets.symmetric(horizontal: 8),
                                    child: Text(
                                      journey['source'],
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  Icon(Icons.arrow_forward, color: Colors.grey),
                                  Container(
                                    padding: EdgeInsets.symmetric(horizontal: 8),
                                    child: Text(
                                      journey['destination'],
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),

                          SizedBox(height: 12),

                          // Travel details
                          SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Row(
                              children: [
                                Icon(Icons.directions_bus, size: 16, color: Colors.grey),
                                SizedBox(width: 8),
                                Text(
                                  '${journey['travelName']} • ${journey['busType']}',
                                  style: TextStyle(color: Colors.grey),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 8),

                          // Date and seat
                          Row(
                            children: [
                              Icon(Icons.calendar_today, size: 16, color: Colors.grey),
                              SizedBox(width: 8),
                              Text(
                                '${_formatDate(journey['date'])} • Seat ${journey['seats'].join(', ')}',
                                style: TextStyle(color: Colors.grey),
                              ),
                            ],
                          ),

                          SizedBox(height: 8),

                          // Boarding point
                          Row(
                            children: [
                              Icon(Icons.location_on, size: 16, color: Colors.grey),
                              SizedBox(width: 8),
                              Text(
                                'Boarding: ${journey['boardingPoint']}',
                                style: TextStyle(color: Colors.grey),
                              ),
                            ],
                          ),
                          SizedBox(height: 8),

                          // Dropping point
                          Row(
                            children: [
                              Icon(Icons.location_on, size: 16, color: Colors.grey),
                              SizedBox(width: 8),
                              Text(
                                'Dropping: ${journey['droppingPoint']}',
                                style: TextStyle(color: Colors.grey),
                              ),
                            ],
                          ),

                          SizedBox(height: 16),
                          Divider(height: 1),
                          SizedBox(height: 16),

                          // Passenger details
                          Text(
                            'Passenger Details',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),

                          SizedBox(height: 8),

                          // Display all passengers
                          Column(
                            children: passengers.map((passenger) => Padding(
                              padding: EdgeInsets.only(bottom: 12),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    passenger['name'] ?? 'Name not available',
                                    style: TextStyle(fontSize: 15, color: Colors.green),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    '${passenger['age'] ?? 'N/A'} yrs • ${_getGenderText(passenger['gender'])}',
                                    style: TextStyle(color: Colors.grey),
                                  ),
                                  Text(
                                    'Seat: ${passenger['seat'] ?? 'N/A'}',
                                    style: TextStyle(color: Colors.grey),
                                  ),
                                ],
                              ),
                            )).toList(),
                          ),

                          SizedBox(height: 16),
                          Divider(height: 1),
                          SizedBox(height: 16),

                          // Booking and payment info
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Booked on',
                                    style: TextStyle(color: Colors.grey),
                                  ),
                                  Text('$formattedDate at $formattedTime'),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                    'Amount paid',
                                    style: TextStyle(color: Colors.grey),
                                  ),
                                  Text(
                                    '₹${booking['invoiceAmount']}',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                      color: Colors.green.shade700,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    // Cancel button
                    if (booking['bookingStatus'] == 'Confirmed')
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          border: Border(top: BorderSide(color: Colors.grey.shade200)),
                        ),
                        child: TextButton(
                          onPressed: () {
                            _showCancelDialog(context, booking);
                          },
                          child: Text(
                            'CANCEL',
                            style: TextStyle(color: Colors.red),
                          ),
                        ),
                      ),
                  ],
                ),
              );
            }).toList(),
          );
        },
      ),
    );
  }

  String _getGenderText(dynamic genderCode) {
    if (genderCode == null) return 'N/A';
    if (genderCode == '1') return 'Male';
    if (genderCode == '2') return 'Female';
    if (genderCode == '3') return 'Other';
    return genderCode.toString();
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'confirmed':
        return Colors.green.shade600;
      case 'cancelled':
        return Colors.red.shade600;
      case 'pending':
        return Colors.orange.shade600;
      default:
        return Colors.blue.shade600;
    }
  }

  String _formatDate(String dateString) {
    try {
      final date = DateTime.parse(dateString);
      return DateFormat('MMM dd, yyyy').format(date);
    } catch (e) {
      return dateString;
    }
  }

  final List<String> cancellationReasons = [
    'Change of travel plans',
    'Found better alternative',
    'Bus timing not suitable',
    'Personal emergency',
    'Other reason'
  ];

  void _showCancelDialog(BuildContext context, DocumentSnapshot booking) {
    String selectedReason = cancellationReasons[0];

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) {
          return AlertDialog(
            title: Text('Cancel Booking'),
            content: SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: MediaQuery.of(context).size.width * 0.8,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text('Are you sure you want to cancel this booking?'),
                    SizedBox(height: 16),
                    DropdownButtonFormField<String>(
                      value: selectedReason,
                      isExpanded: true,
                      items: cancellationReasons.map((String reason) {
                        return DropdownMenuItem<String>(
                          value: reason,
                          child: Text(
                            reason,
                            overflow: TextOverflow.ellipsis,
                          ),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          selectedReason = value!;
                        });
                      },
                      decoration: InputDecoration(
                        labelText: 'Reason for cancellation',
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(horizontal: 12),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('NO'),
              ),
              TextButton(
                onPressed: () async {
                  Navigator.pop(context);
                  await _cancelBooking(context, booking, selectedReason);
                },
                child: Text('YES, CANCEL', style: TextStyle(color: Colors.red)),
              ),
            ],
          );
        },
      ),
    );
  }

  // Future<void> _cancelBooking(BuildContext context, DocumentSnapshot booking, String remarks) async {
  //   final currentUser = FirebaseAuth.instance.currentUser;
  //   if (currentUser == null) return;
  //
  //   showDialog(
  //     context: context,
  //     barrierDismissible: false,
  //     builder: (context) => Center(child: CircularProgressIndicator()),
  //   );
  //
  //   try {
  //     const String apiUrl = "http://65.0.115.185:8081/cancel-booking";
  //
  //     final busId = booking['busId'] is int
  //         ? booking['busId'] as int
  //         : int.parse(booking['busId'].toString());
  //
  //     final seatIds = (booking['journeyDetails']['seats'] as List).map((seat) {
  //       return seat is int ? seat : int.parse(seat.toString());
  //     }).toList();
  //
  //     final Map<String, dynamic> requestBody = {
  //       "EndUserIp": "122.171.16.249",
  //       "ClientId": "180187",
  //       "UserName": "Namma434",
  //       "Password": "Namma@4341",
  //       "BusId": busId,
  //       "SeatId": seatIds,
  //       "Remarks": remarks
  //     };
  //
  //     const headers = {
  //       "Content-Type": "application/json",
  //       "Api-Token": "Namma@90434#34",
  //     };
  //
  //     final response = await http.post(
  //       Uri.parse(apiUrl),
  //       headers: headers,
  //       body: jsonEncode(requestBody),
  //     );
  //
  //     Navigator.pop(context);
  //
  //     if (response.statusCode == 200) {
  //       final responseData = jsonDecode(response.body);
  //
  //       if (responseData['Error'] == null ||
  //           (responseData['Error']['ErrorCode'] == 0 &&
  //               responseData['Error']['ErrorMessage'].isEmpty)) {
  //
  //         await FirebaseFirestore.instance
  //             .collection('customers')
  //             .doc(currentUser.uid)
  //             .collection('bookings')
  //             .doc(booking.id)
  //             .update({
  //           'bookingStatus': 'Cancelled',
  //           'lastUpdated': FieldValue.serverTimestamp(),
  //           'cancellationTime': FieldValue.serverTimestamp(),
  //           'cancellationDetails': {
  //             'apiResponse': responseData,
  //             'cancelledAt': DateTime.now().toIso8601String(),
  //             'refundAmount': responseData['Response']?['RefundAmount'],
  //             'cancellationReason': remarks,
  //           }
  //         });
  //
  //         ScaffoldMessenger.of(context).showSnackBar(
  //           SnackBar(
  //             content: Text('Your booking is canceled. Refund will be processed within 25 hours based on cancellation charges.'),
  //             backgroundColor: Colors.green,
  //             duration: Duration(seconds: 4),
  //           ),
  //         );
  //
  //         setState(() {}); // Refresh the UI
  //       } else {
  //         ScaffoldMessenger.of(context).showSnackBar(
  //           SnackBar(
  //             content: Text(responseData['Error']['ErrorMessage'] ?? 'Cancellation failed'),
  //             backgroundColor: Colors.red,
  //           ),
  //         );
  //       }
  //     } else {
  //       ScaffoldMessenger.of(context).showSnackBar(
  //         SnackBar(
  //           content: Text('Server returned status code ${response.statusCode}'),
  //           backgroundColor: Colors.red,
  //         ),
  //       );
  //     }
  //   } catch (e) {
  //     Navigator.pop(context);
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       SnackBar(
  //         content: Text('Cancellation failed: ${e.toString()}'),
  //         backgroundColor: Colors.red,
  //       ),
  //     );
  //   }
  // }

  Future<void> _cancelBooking(BuildContext context, DocumentSnapshot booking, String remarks) async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    // Show loading indicator
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Center(child: CircularProgressIndicator()),
    );

    try {
      const String apiUrl = "https://namma-savaari-api-backend.vercel.app/cancel-booking";

      final busId = booking['busId'] is int
          ? booking['busId'] as int
          : int.parse(booking['busId'].toString());

      final seatId = booking['journeyDetails']['seatNumber'] is int
          ? booking['journeyDetails']['seatNumber'] as int
          : int.parse(booking['journeyDetails']['seatNumber'].toString());

      final Map<String, dynamic> requestBody = {
        "EndUserIp": "122.171.16.249",
        "ClientId": "180187",
        "UserName": "Namma434",
        "Password": "Namma@4341",
        "BusId": busId,
        "SeatId": seatId,
        "Remarks": remarks
      };

      const headers = {
        "Content-Type": "application/json",
        "Api-Token": "Namma@90434#34",
      };

      final response = await http.post(
        Uri.parse(apiUrl),
        headers: headers,
        body: jsonEncode(requestBody),
      );

      // Hide loading indicator
      Navigator.pop(context);

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);

        if (responseData['Error'] == null ||
            (responseData['Error']['ErrorCode'] == 0 &&
                responseData['Error']['ErrorMessage'].isEmpty)) {

          // Update Firestore booking status
          await FirebaseFirestore.instance
              .collection('customers')
              .doc(currentUser.uid)
              .collection('bookings')
              .doc(booking.id)
              .update({
            'bookingStatus': 'Cancelled',
            'lastUpdated': FieldValue.serverTimestamp(),
            'cancellationTime': FieldValue.serverTimestamp(),
            'cancellationDetails': {
              'apiResponse': responseData,
              'cancelledAt': DateTime.now().toIso8601String(),
              'refundAmount': responseData['Response']?['RefundAmount'],
              'cancellationReason': remarks,
            }
          });

          // Show success snackbar message with refund info
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Your booking is canceled. Refund will be processed within 25 hours based on cancellation charges.'),
              backgroundColor: Colors.green,
              duration: Duration(seconds: 4),
            ),
          );

          // Refresh the UI to disable the cancel button
          (context as Element).markNeedsBuild();

        } else {
          // Show API error message
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(responseData['Error']['ErrorMessage'] ?? 'Cancellation failed'),
              backgroundColor: Colors.red,
            ),
          );
        }
      } else {
        // Show HTTP error message
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Server returned status code ${response.statusCode}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      // Hide loading indicator in case of error
      Navigator.pop(context);

      // Show exception error message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Cancellation failed: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
}