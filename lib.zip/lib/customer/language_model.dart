// bus_booking_application

// language_model.dart

// class LanguageModel {
//   static const Map<String, Map<String, String>> translations = {
//     'en': {
//       'more': 'More',
//       'offers': 'Offers',
//       'rate_app': 'Rate App',
//       'help': 'Help',
//       'preferences': 'Preferences',
//       'country': 'Country',
//       'language': 'Language',
//       'india': 'India',
//       'select_language': 'Select Language',
//     },
//     'hi': {
//       'more': 'अधिक',
//       'offers': 'ऑफर',
//       'rate_app': 'ऐप रेट करें',
//       'help': 'सहायता',
//       'preferences': 'प्राथमिकताएँ',
//       'country': 'देश',
//       'language': 'भाषा',
//       'india': 'भारत',
//       'select_language': 'भाषा चुनें',
//     },
//     'ta': {
//       'more': 'மேலும்',
//       'offers': 'சலுகைகள்',
//       'rate_app': 'ஆபை மதிப்பீடு செய்',
//       'help': 'உதவி',
//       'preferences': 'முன்னுரிமைகள்',
//       'country': 'நாடு',
//       'language': 'மொழி',
//       'india': 'இந்தியா',
//       'select_language': 'மொழி தேர்ந்தெடுக்கவும்',
//     },
//     'te': {
//       'more': 'మరింత',
//       'offers': 'ఆఫర్లు',
//       'rate_app': 'యాప్ రేటింగ్',
//       'help': 'సహాయం',
//       'preferences': 'ప్రాధాన్యతలు',
//       'country': 'దేశం',
//       'language': 'భాష',
//       'india': 'భారతదేశం',
//       'select_language': 'భాషను ఎంచుకోండి',
//     },
//     'kn': {
//       'more': 'ಹೆಚ್ಚು',
//       'offers': 'ಆಫರ್‌ಗಳು',
//       'rate_app': 'ಆ್ಯಪ್ ದರ',
//       'help': 'ಸಹಾಯ',
//       'preferences': 'ಆಸಕ್ತಿ',
//       'country': 'ದೇಶ',
//       'language': 'ಭಾಷೆ',
//       'india': 'ಭಾರತ',
//       'select_language': 'ಭಾಷೆ ಆಯ್ಕೆಮಾಡಿ',
//     },
//   };
// }
