// bus_booking_application

// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
//
// class ReschedulePage extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Ticket Reschedule / Cancellation Help'),
//       ),
//       body: Center(
//         child: Text('Reschedule and Cancellation Help Content'),
//       ),
//     );
//   }
// }