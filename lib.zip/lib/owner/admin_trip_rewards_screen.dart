// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
//
// class AdminTripRewardsScreen extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Reschedule / Cancel Tickets'),
//       ),
//       body: Center(child: Text('Reschedule / Cancel Tickets Page')),
//     );
//   }
// }