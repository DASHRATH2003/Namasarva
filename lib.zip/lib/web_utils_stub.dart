// This file is used for Android, iOS, Windows, macOS, and Linux
bool isMobileWeb() {
  return false; // Mobile detection only needed for web
}
